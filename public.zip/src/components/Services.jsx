// import React from 'react';
// import "../index.css"
// import { ChevronRight } from 'lucide-react';

// const Services = () => {
//     return (
//         <div className='container'>
//             <div className="wrapper  mt-[50px]">
//             <h1 className='text-[30px] font-bold'>Bizning Xizmatlar</h1>
//                <div className="cards">
//                 <div className="cardd "><ChevronRight className='text-[blue]' size={20} /> Transport infratuzilmasi va kommunikatsiyalari uchun loyihalash </div>
//                 <div className="cardd"><ChevronRight className='text-[blue]' size={20} /> Texnik-iqtisodiy asoslashni ishlab chiqish</div>
//                 <div className="cardd"><ChevronRight className='text-[blue]' size={20} /> Izlanish (geodeziya, geologiya, gidrologiya)</div>
//                 <div className="cardd"><ChevronRight className='text-[blue]' size={20} /> Batafsil loyihalash</div>
//                 <div className="cardd"><ChevronRight className='text-[blue]' size={20} /> Iqtisodiy va moliyaviy tahlil</div>
//                 <div className="cardd"><ChevronRight className='text-[blue]' size={20} /> Qurilish nazorati</div>
//                 <div className="cardd"><ChevronRight className='text-[blue]' size={20} /> Loyihani boshqarish xizmatlari</div>
//                </div>
//             </div>
//         </div>
//     );
// }

// export default Services;


const Services = () => {
  return (
    <div className="container mx-auto px-4 md:px-6 lg:px-8">
      <div className="wrapper mt-8 md:mt-12 lg:mt-16 max-w-[900px] mx-auto">
        <h1 className="
          font-bold
          text-xl sm:text-2xl md:text-3xl lg:text-4xl
          mb-4 md:mb-6
        ">
          Bizning Xizmatlar
        </h1>

        <div className="cards grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
          {services.map((item, index) => (
            <div key={index} className="
              cardd flex items-start gap-2 md:gap-3
              p-4 md:p-5 lg:p-6
              bg-white shadow-sm hover:shadow-md
              transition-shadow
            ">
              <ChevronRight className="text-blue-600 mt-1 flex-shrink-0" size={20} />
              <span className="text-sm md:text-base leading-relaxed">
                {item}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};