import React from 'react';
import { Handshake } from 'lucide-react';
import "../index.css"
import { NavLink } from 'react-router-dom';
import Footer from '../components/Footer';
import bgImg from "../assets/image7-min.jpg"

const Hamkorlar = () => {
    return (
        <div className='bg-cover bg-center w-full h-full '
                        style={{ backgroundImage: `url(${bgImg})` }}>
           <div className='container'>
            <h1 className='!font-bold text-[30px] '>Hamkorlar</h1>
            <div className="wrapper w-[1220px] bg-blue-600 h-[300px] mt-[20px] rounded-[10px] flex flex-col gap-[20px] justify-center items-center">
                <Handshake size={40} className='text-white' />
                <h1 className='text-[25px] font-bold text-white'>Bizning hamkorlarimiz</h1>
                <p className='text-white'>Orient Geodez MChJ </p>
                <NavLink to={"/aloqa"}><button className='w-[150px] h-[50px] text-blue-600 bg-white  cursor-pointer rounded-[10px]'>Hamkor bolish</button></NavLink>
            </div>
        </div>

        <Footer />
        </div>
      
        
     
    );
}

export default Hamkorlar;
