
import React from 'react';
import "../index.css"
import { Mail, Phone, MapPin } from 'lucide-react';
import Footer from '../components/Footer';
import bgImg from "../assets/image7-min.jpg"

const Aloqa = () => {
    return (

        <div className='bg-cover bg-center w-full h-full'
                style={{ backgroundImage: `url(${bgImg})` }}>
         <div className='container'>
            <h1 className='text-[30px] '>Aloqa</h1>
            <div className='aloqa-box bg-gradient-to-br from-blue-500 to-blue-600 w-[1220px] h-[400px] p-[20px] flex flex-col gap-[20px] rounded-[10px] mt-[20px]'>
                <h1 className='text-[24px] text-white'>Biz bilan bog'laning</h1>
                <div className="tel">
                    <div className="tel-wrapper flex gap-[20px] items-center">
                          <div className="bg-white/20 hover:bg-white/30 active:bg-white/40  rounded-xl p-[10px] shadow-lg transition-all duration-200 hover:shadow-xl border border-white/30 inline-block cursor-pointer">
                        <Phone className=' text-white' strokeWidth={2} />
                    </div>
                    <p className='text-gray-300'>Telefon raqamlar</p>
                    </div>
                    <div className="wrappper pt-[10px] text-white !font-light">
                            <p>+998 77 181 8182</p>
                            <p>+998 50 009 1881</p>
                    </div>
              
                </div>
               <div className="email">
                  <div className="email-wrapper flex gap-[20px] items-center">
                          <div className="bg-white/20 hover:bg-white/30 active:bg-white/40  rounded-xl p-[10px] shadow-lg transition-all duration-200 hover:shadow-xl border border-white/30 inline-block cursor-pointer">
                        <Mail className=' text-white' strokeWidth={2} />
                    </div>
                    <p className='text-gray-300'>Email</p>
                    </div>
                    <div className="wrappper pt-[10px] text-white !font-light">
                            <p>proektms@gmail.com</p>
                    </div>
              
               </div>

               <div className="location">
                  <div className="loc-wrapper flex gap-[20px] items-center">
                          <div className="bg-white/20 hover:bg-white/30 active:bg-white/40  rounded-xl p-[10px] shadow-lg transition-all duration-200 hover:shadow-xl border border-white/30 inline-block cursor-pointer">
                        <MapPin className=' text-white' strokeWidth={2} />
                    </div>
                    <p className='text-gray-300'>Manzil</p>
                    </div>
                    <div className="wrappper pt-[10px] text-white !font-light">
                            <p>Manzil Toshkent shahri, Yangihayot tumani, 3-QURILISH, 3-uy, 49-xona</p>
                    </div>
              
               </div>
            </div>
        </div>
        <Footer />
        </div>
       

    
    );
}

export default Aloqa;