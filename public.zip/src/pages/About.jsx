import React from 'react';
import "../index.css"
import { Dot, MapPin } from 'lucide-react';
import Footer from '../components/Footer';
import bgImg from "../assets/image7-min.jpg"

const About = () => {
    return (
        <div className='bg-cover bg-center w-full h-full'
                        style={{ backgroundImage: `url(${bgImg})` }}>
   <div className='container'>
            <div className="wrapper pt-[20px]">
                <h1 className='text-[30px]  mb-[10px]'>Korxona haqida</h1>

                <div className="material-wrapper bg-white w-full min-h-screen rounded-[10px] p-[20px]">
                    <div className="container">
                        <div className="text-wrapper flex gap-[5px]">
                            <h1 className='text-[20px] font-light'>"Proekt Max-Stroy" MCHJ </h1>
                            <p className='text-[20px]'>respublika yol quirilishob'ektlarining loyiha-qidiruv tashkilotlari orasida yetakchi o'rinlardan birini egallaydi.</p>
                        </div>
                        <p className='font-light mt-[20px]'>Korxonamiz transport infratuzilmasi va kommunikatsiyalari uchun loyihalash xizmatlarining to'liq hajmini ta'minlash, texnik-iqtisodiy asoslashni ishlab chiqish, izlanish (geodeziya, geologiya, gidrologiya), batafsil loyihalash, iqtisodiy va moliyaviy tahlil, qurilish nazorati va loyihani boshqarish xizmatlarini ko'rsatadi.</p>

                        <h1 className='mt-[50px] text-[20px] mb-[20px]'>Xizmatlarimiz</h1>


                        <div className="card-ota flex flex-col gap-[20px]">
                            <div className="card4 w-[99%] bg-blue-600  h-[50px] rounded-[10px] flex items-center gap-[5px] p-[5px]">
                                <Dot size={36} className='text-blue-900' />
                                <p className='text-white'>Transport infratuzilmasi va kommunikatsiyalari uchun loyihalash</p>
                            </div>
                            <div className="card4 w-[99%] bg-blue-600 h-[50px] rounded-[10px] flex items-center gap-[5px] p-[5px]">
                                <Dot size={36} className='text-blue-900' />
                                <p className='text-white'>Texnik-iqtisodiy asoslashni ishlab chiqish</p>
                            </div>
                            <div className="card4 w-[99%] bg-blue-600 h-[50px] rounded-[10px] flex items-center gap-[5px] p-[5px]">
                                <Dot size={36} className='text-blue-900' />
                                <p className='text-white'>Izlanish (geodeziya, geologiya, gidrologiya)</p>
                            </div>
                            <div className="card4 w-[99%] bg-blue-600 h-[50px] rounded-[10px] flex items-center gap-[5px] p-[5px]">
                                <Dot size={36} className='text-blue-900' />
                                <p className='text-white'>Batafsil loyihalash</p>
                            </div>
                            <div className="card4 w-[99%] bg-blue-600 h-[50px] rounded-[10px] flex items-center gap-[5px] p-[5px]">
                                <Dot size={36} className='text-blue-900' />
                                <p className='text-white'>Iqtisodiy va moliyaviy tahlil</p>
                            </div>
                            <div className="card4 w-[99%] bg-blue-600 h-[50px] rounded-[10px] flex items-center gap-[5px] p-[5px]">
                                <Dot size={36} className='text-blue-900' />
                                <p className='text-white'>
                                    Qurilish nazorati</p>
                            </div>
                            <div className="card4 w-[99%] bg-blue-600 h-[50px] rounded-[10px] flex items-center gap-[5px] p-[5px]">
                                <Dot size={36} className='text-blue-900' />
                                <p className='text-white'>
                                    Loyihani boshqarish xizmatlari</p>
                            </div>

                        </div>
                    </div>




                </div>

                <div className="malumot bg-blue-800 w-full h-[300px] mt-[50px] mb-[50px] p-[20px] rounded-[10px]">
                    <h1 className='text-[25px] text-white'>Yuridik ma'lumotlar</h1>

                    <h3 className='text-gray-200 text-[15px] mt-[6px]'>Toliq nomi</h3>
                    <h1 className='text-white text-[18px]'>"Proekt Max-Stroy" MCHJ</h1>

                    <h3 className='text-gray-200 text-[15px] mt-[6px]'>STIR</h3>
                    <h1 className='text-white text-[18px]'>308 106 564</h1>

                    <h3 className='text-gray-200 text-[15px] mt-[6px]'>Royxatga olingan</h3>
                    <h1 className='text-white text-[18px]'>21.01.2021</h1>

                    <h3 className='text-gray-200 text-[15px] mt-[6px]'>Litsenziya</h3>
                    <h1 className='text-white text-[18px]'>АЛ-002018</h1>
                </div>

                <div className="manzil w-full h-[160px] bg-white rounded-[10px] mb-[20px] p-[15px]">
                    <h1 className='text-[25px] mb-[20px]'>Manzil</h1>
                    <div className="text-wrapper2 flex items-center gap-[10px]">
                        <MapPin size={22} className='text-[blue]' />
                        <h1 className='text-[20px]'>Ofis manzili</h1>
                    </div>
                    <p className='text-[gray] mt-[15px]'>Toshkent shahri, Yangihayot tumani, 3-QURILISH, 3-uy, 49-xona</p>
                </div>

            
            </div>

        </div>
      <Footer />
        </div>
       
        
      
    );
}

export default About;
